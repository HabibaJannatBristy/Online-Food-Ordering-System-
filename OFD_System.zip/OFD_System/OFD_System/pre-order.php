<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");  
error_reporting(0);  
session_start(); 

if($_SERVER['REQUEST_METHOD']=="POST"){
    $id= $_SESSION['user_id'];
    $name= $_REQUEST['name'];
    $email= $_REQUEST['email'];
    $phn= $_REQUEST['phn'];
    $food= $_REQUEST['food'];
    $qty= $_REQUEST['qty'];
    $address= $_REQUEST['address'];
    $a_comment=$_REQUEST['a_comment'];
    $sql2 ="SELECT * FROM `dishes` where d_id=$food";
    $result2 = mysqli_query($db, $sql2);
    $row2= mysqli_fetch_array($result2);
    $title= $row2['title'];
    $price= $row2['price'];
    $total_price=$price * $qty;
    $commision= $total_price/10;
    $sql3 ="INSERT INTO `pre_orders` (`u_id`, `d_id`, `title`, `s_name`, `s_email`, `s_phone`, 
    `s_address`, `price`, `qty`, `total_price`, `commision`, `a_comment`, `status`, `h_time`, 
    `transaction_phone`, `transaction_id`, `date`) VALUES ('$id', '$food', '$title', '$name', '$email',
     '$phn', '$address', '$price', '$qty', '$total_price', '$commision', NULL, NULL, 'pending', NULL, NULL, 
     current_timestamp());";

    $result3 =mysqli_query($db, $sql3);

    $sql4 = "SELECT * FROM `pre_orders` WHERE u_id=$id ORDER By pre_id DESC LIMIT 1";
    $result4=mysqli_query($db, $sql4);
    $row4 = mysqli_fetch_array($result4);
    $pre_id= $row4['pre_id'];
    header("location:transaction_preOrder.php?order_id=$pre_id");
}
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Home</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body class="home">

    <?php
    include("partials/header.php");
   ?>
    <section class="hero bg-image" data-image-src="images/img/pimg.jpg">
        <div class="hero-inner">
            <div class="container text-center font-white">
                <h1>You Pick, We Deliver </h1>

                <div class="banner-form">
                    <form class="form-inline">

                    </form>
                </div>

            </div>
        </div>

    </section>
    <div class="container">
        <div class="title text-xs-center m-2 m-b-30">
            <h2>Food Pre-Order</h2>
            <?php
            if(empty($_SESSION['user_id'])){
                echo '<p><strong>Log In </strong> to <strong>Pre-Order </strong>your food.</p>';
            }
            else{
                echo '<p>You have to <strong>pay 50% as advance </strong> of<strong> Total Price </strong> of your food.</p>';
            }
            ?>
        </div>
        <div class="row">
            <?php
            if(!empty($_SESSION['user_id'])){
                $id= $_SESSION['user_id'];
                $sql= "SELECT * FROM `users` where u_id=$id";
                $result= mysqli_query($db, $sql);
                $row= mysqli_fetch_array($result);

            ?>
            <div class="container-fluid">
                <form action="pre-order.php" method="post" class="m-3">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" aria-describedby="emailHelp"
                           value=<?php echo $row['username'];?> required >
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp"
                        value=<?php echo $row['email'];?> required>
                    </div>
                    <div class="form-group">
                        <label for="phn">Phone Number</label>
                        <input type="number" class="form-control" id="phn" name="phn" aria-describedby="emailHelp"
                        value=<?php echo $row['phone'];?> required>
                    </div>
                    <div class="form-group">
                        <label for="food">Food</label>
                       <select name="food" id="food" class="form-control">
                        <?php
                            $sql1= "SELECT * FROM `dishes`";
                            $result1= mysqli_query($db, $sql1);
                            while($row1= mysqli_fetch_array($result1)){
                            echo '<option value="'.$row1['d_id'].'">'.$row1['title'].' | '.$row1['price'].'</option>';
                            }
                        ?>
                            
                       </select>
                    </div>
                    <div class="form-group">
                        <label for="number">Quantity</label>
                        <input type="number" class="form-control" id="qty" name="qty" aria-describedby="emailHelp"
                        required>
                    </div>
                    <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" id="address" name="address" aria-describedby="emailHelp"
                        value=<?php echo $row['address'];?>required>
                    </div>
                    <div class="form-group">
                        <label for="a_comment">Additional Comment (Optional)</label>
                        <textarea class="form-control" id="a_comment" name="a_comment" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">Continue</button>
                    
                </form>
            </div>
            <?php }?>
        </div>
    </div>
    <?php
    include("partials/footer.php");
   ?>



    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
</body>

</html>