<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");  
error_reporting(0);  
session_start(); 

if($_SERVER['REQUEST_METHOD']=="POST"){
   $transaction_id= $_REQUEST['transaction_id'];
   $transaction_phone= $_REQUEST['transaction_phone'];
   $id= $_REQUEST['id'];
   $sql1= "UPDATE `pre_orders` SET `transaction_phone` = '0192000' WHERE `pre_orders`.`pre_id` = $id";
   $sql2= "UPDATE `pre_orders` SET `transaction_id` = '$transaction_id' WHERE `pre_id` = $id";
   $result1 = mysqli_query($db, $sql1);
   $result2 = mysqli_query($db, $sql2);
    
  
    header("location:your_pre_orders.php");
}
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Home</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>

<body class="home">

    <?php
    include("partials/header.php");
   ?>
    <section class="hero bg-image" data-image-src="images/img/pimg.jpg">
        <div class="hero-inner">
            <div class="container text-center font-white">
                <h1>You Pick, We Deliver </h1>

                <div class="banner-form">
                    <form class="form-inline">

                    </form>
                </div>

            </div>
        </div>

    </section>
    <div class="container">
        <div class="title text-xs-center m-2 m-b-30">
            <h2>Food Pre-Order</h2>
            <p><strong>Please pay 50% of your food price </strong> to <strong>Bkash: 0131000000</strong></p>
        </div>
        <div class="container-fluid">
            <div class="row">
                <?php
                $id= $_GET['order_id'];
                $sql= "SELECT * FROM `pre_orders` where pre_id=$id";
                $result= mysqli_query($db, $sql);
                $row= mysqli_fetch_array($result);

            ?>
                <div class="col-md-7">
                    <form action="" method="post" class="m-3">
                        <input type="hidden" name="id" value=<?php echo $id;?>>
                        <div class="form-group">
                            <label for="transaction_phone">Your Bkash Number</label>
                            <input type="number" class="form-control" id="transaction_phone" name="transaction_phone" aria-describedby="emailHelp"
                                required>
                        </div>
                        <div class="form-group">
                            <label for="transaction_id">Transaction Id</label>
                            <input type="text" class="form-control" id="transaction_id" name="transaction_id"
                                aria-describedby="emailHelp" required>
                        </div>
                        <button type="submit" class="btn btn-success">Save</button>
                    </form>
                </div>
                <div class="col-md-5">
                    <div class="card p-3">
                        <div class="card-body">
                            <h2 class="card-title">Order Summary</h2>
                            <hr>
                            <h4 class="card-subtitle mb-2 text-muted">Shipping Address</h4>
                            <p><strong>Name: </strong><?php echo $row['s_name'];?></p>
                            <p><strong>Phone: </strong><?php echo $row['s_phone'];?></p>
                            <p><strong>Email: </strong><?php echo $row['s_email'];?></p>
                            <p><strong>Address: </strong><?php echo $row['s_address'];?></p>
                            <hr>
                            <h4 class="card-subtitle mb-2 text-muted">Food Details</h4>
                            <p><strong>Food Name: </strong><?php echo $row['title'];?></p>
                            <p><strong>Quantity: </strong><?php echo $row['qty'];?></p>
                            <p><strong>Price: </strong><?php echo $row['price'];?> tk</p>
                            <p><strong>Total Price: </strong><?php echo $row['total_price'];?> tk</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    include("partials/footer.php");
   ?>



    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/headroom.js"></script>
    <script src="js/foodpicky.min.js"></script>
</body>

</html>